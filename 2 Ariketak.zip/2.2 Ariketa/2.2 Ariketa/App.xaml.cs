﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace _2._2_Ariketa
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
